#ifdef __cplusplus
extern "C" {
#endif

void draw_spr16_full(u16 *d, void *s, u16 *pal, int lines);

#ifdef __cplusplus
}
#endif
