char build_version[] = "0.37 BETA 5 ("__DATE__")";
